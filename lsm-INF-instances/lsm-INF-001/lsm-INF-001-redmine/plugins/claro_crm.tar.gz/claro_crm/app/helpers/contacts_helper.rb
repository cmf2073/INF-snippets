module ContactsHelper
  def show_error_messages messages
    names_map = {
        "last_name" => "El campo <strong>apellido</strong>",
        "first_name" => "El campo <strong>nombre</strong>",
        "job" => "El campo <strong>cargo/puesto</strong>",
        "rank" => "El campo <strong>categoria</strong>",
        "phone_numbers" => "El campo <strong>telefono</strong>",
        "emails" => "El campo <strong>email</strong>",
        "Notas" => "El campo <strong>notas</strong>",
        "company_name" => "El campo <strong>empresa</strong>",
    }
    result = messages.map do |m|
      names_map.each do |k,v|
        m.to_s.gsub! k, v
      end
      m.insert 0, "<p>"
      m << "</p>"
    end
    return result.join "\n"
  end

  def country_link country
    link = link_to country_path(country.code), :class => "btn-pais", :id => country.code, :remote => true do
      "<i class='icon-pais pais-#{country.code}'></i><span>#{country.name}</span><i class='icon-pais-flecha'></i>".html_safe
    end
  end
end
