class CountriesController < ApplicationController
  unloadable

  def edit
    @country = Country.find_by_code(params[:id].downcase)
    respond_to do |format|
      format.js
    end
  end

  def update
    @country = Country.find_by_code(params[:id].downcase)
    @country.update_attributes(params[:country])
    respond_to do |format|
      format.js
    end
  end

end
