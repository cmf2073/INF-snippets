class ContactsController < ApplicationController
  unloadable

  before_filter :authorize_global, :only => [:new_contact,:edit,:index,:country,:edit, :destroy]

  def index
    @countries_north = Country.where(zone: "norteamerica", active: true)
    @countries_central = Country.where(zone: "centroamerica", active: true)
    @countries_caribbean = Country.where(zone: "caribe", active: true)
    @countries_south = Country.where(zone: "sudamerica", active: true)
    @contacts = Contact.all.map {|c| "#{c.first_name} #{c.last_name},#{c.company.name},#{c.country.code}"}.to_json.html_safe
  end

  def new_contact
    RolesController
    code = params[:code].downcase
    country = Country.find_by_code(code)
    @contact = Contact.new
    @contact.country = country
    @photo = Photo.find_or_create_by_id(@contact.photo_id)
    @contact.photo_id = @photo.id
    @contact.photo = @photo

    @photo.active = false
    respond_to do |format|
      format.js
    end
  end

  def new_phone
    respond_to do |format|
      format.js
    end
  end

  def create

    company = Company.find_or_create_by_name(params[:contact][:company_name])
    photo = Photo.find_or_create_by_id(params[:contact][:photo])
    @contact = Contact.new(params[:contact])
    @contact.photo_id = photo.id
    @contact.photo = photo
    photo.active = false
    @contact.company = company
    if @contact.save
      respond_to do |format|
        @contacts = Contact.all.map {|c| "#{c.first_name} #{c.last_name},#{c.company.name},#{c.country.code}"}.to_json.html_safe
        format.js
      end
    end
  end

  def edit
    @contact = Contact.find_by_id(params[:id])
    @photo = @contact.photo
    respond_to do |format|
      format.js
    end
  end

  def update
    @contact = Contact.find_by_id(params[:id])
    company = Company.find_or_create_by_name(params[:contact][:company_name])
    if @contact.update_attributes(params[:contact]) && @contact.update_attributes(company: company)
      clean_company_if_empty company
      respond_to do |format|
        format.js
        @contacts = Contact.all.map {|c| "#{c.first_name} #{c.last_name},#{c.company.name},#{c.country.code}"}.to_json.html_safe

      end


    else
      Rails.logger.warn "ERROR UPDATING"
    end
  end

  def destroy
    @contact = Contact.find(params[:id])
    contact_company = @contact.company
    if @contact.destroy
      clean_company_if_empty contact_company
      respond_to do |format|
        format.js
        @contacts = Contact.all.map {|c| "#{c.first_name} #{c.last_name},#{c.company.name},#{c.country.code}"}.to_json.html_safe

      end
    end
  end

  def country
    @allowedNew = User.current.allowed_to?({:controller => 'contacts', :action => 'new_contact'}, @project, :global => true)
    @allowedEdit = User.current.allowed_to?({:controller => 'countries', :action => 'edit'}, @project, :global => true)
    code = params[:code].downcase
    @current_country = Country.where(code: code.to_s).first if code
    if @current_country
      @contacts = Country.where(code: code).first.contacts.order('rank DESC').order(:last_name).all.group_by(&:company_id).map{|k,v| k = Company.find_by_id(k).name, v}.sort
      respond_to do |format|
        format.html
        format.js
      end
    else
      respond_to do |format|
        format.html { render :text => "Invalid" }
      end
    end
  end

  private


  # cleans the company if it has no contacts left
  def clean_company_if_empty company
    unless company.contacts.count > 0
      company.destroy
    end
  end

end
