class PhotosController < ApplicationController

  unloadable


  def update
    @photo = Photo.find_by_id(params[:id])
    @contact = Contact.find_by_id(@photo.contact_id)
    @country = Country.find_by_id(@contact.country_id)
   if  @photo.update_attributes(params[:photo])
    respond_to do |format|
      format.js
    end
   end
  end

  def take_photo
    @photo = Photo.find_by_id(params[:id])
    respond_to do |format|
      format.js
    end
  end

  def add_photo
    @photo = Photo.find_by_id(params[:id])
    contact = Contact.find_by_id(@photo.contact_id)
    @country = Country.find_by_id(contact.country_id)
    respond_to do |format|
      format.js
    end

  end

  def destroy
    @photo = Photo.find_by_id(params[:id])
    @contact = Contact.find_by_id(@photo.contact_id)
    @country = Country.find_by_id(@contact.country_id)
    @photo.active = false
    @photo.update_attributes(active = false)
    if @photo.active == false
      respond_to do |format|
        format.js
      end

    end
  end

end