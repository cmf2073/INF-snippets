class PhoneNumber < ActiveRecord::Base
  belongs_to :contact
  unloadable
end
