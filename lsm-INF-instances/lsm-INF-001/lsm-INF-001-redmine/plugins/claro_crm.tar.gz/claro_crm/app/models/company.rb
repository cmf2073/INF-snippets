class Company < ActiveRecord::Base
  has_many :contacts
  unloadable
end
