class Photo  < ActiveRecord::Base
  belongs_to :contact
  unloadable

  has_attached_file :imagen,
                    :path => "public/plugin_assets/claro_crm/images/system/:class/:id/:style/:filename",
                    :url => "system/:class/:id/:style/:filename",
                    :styles => { :medium => "152x152>", :thumb => "100x100>" },
                    :default_url => "path to default image"

  # Validate the attached image is image/jpg, image/png, etc
  validates_attachment_content_type :imagen, :content_type => /\Aimage\/.*\Z/

end