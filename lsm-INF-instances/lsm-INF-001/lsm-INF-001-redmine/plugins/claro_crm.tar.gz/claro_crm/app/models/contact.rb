#encoding: utf-8
class Contact < ActiveRecord::Base
  MIN_EMAILS = 1
  MAX_EMAILS = 2
  MIN_PHONES = 0
  MAX_PHONES = 2

  belongs_to :company
  belongs_to :country
  has_many :emails
  has_many :phone_numbers
  attr_accessor :company_name
  has_one :photo
  validates :first_name, :last_name, :job, :rank, :company_name, presence: true
  validates :rank, numericality: { greater_than: 0 }
  validates :notes, length: { maximum: 200 }


  validate :valid_phone_numbers_count, :valid_emails_count
  accepts_nested_attributes_for :phone_numbers,
                                :reject_if => :reject_phone,
                                allow_destroy: true
  accepts_nested_attributes_for :emails,
                                :reject_if => :reject_email,
                                allow_destroy: true

  def reject_email(attributes)
    exists = attributes['id'].present?
    empty = attributes[:email].blank?
    attributes.merge!({:_destroy => 1}) if exists and empty
    return (!exists and empty)
  end

  def reject_phone(attributes)
    exists = attributes['id'].present?
    empty = attributes[:number].blank?
    attributes.merge!({:_destroy => 1}) if exists and empty
    return (!exists and empty)
  end

  def valid_emails_count
    emails_count = self.emails.select{ |e| ! e.email.strip.empty? }.count
    unless (MIN_EMAILS..MAX_EMAILS).member? emails_count
      errors.add(:base, "Ingrese <strong>uno o más</strong> e-mails")
    end
  end

  def valid_phone_numbers_count
    phone_numbers_count = self.phone_numbers.select{ |p| ! p.number.strip.empty? && /\A[+-]?\d+\Z/.match(p.number.to_s) }.count
    unless (MIN_PHONES..MAX_PHONES).member? phone_numbers_count
      errors.add(:base, "Ingrese <strong>uno o más</strong> números de teléfono")
    end
  end

  unloadable
end
