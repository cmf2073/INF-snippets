class CreateContacts < ActiveRecord::Migration
  def change
    create_table :contacts do |t|
      t.string :first_name
      t.string :last_name
      t.string :job
      t.integer :rank
      t.string :notes
      t.references :country
      t.references :company
      t.references :photo
    end
    add_index :contacts, :country_id
    add_index :contacts, :company_id
    add_index :contacts, :photo_id

  end
end
