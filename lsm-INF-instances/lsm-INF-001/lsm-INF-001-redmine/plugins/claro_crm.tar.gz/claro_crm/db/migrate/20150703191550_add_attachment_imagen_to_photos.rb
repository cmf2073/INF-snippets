class AddAttachmentImagenToPhotos < ActiveRecord::Migration
  def self.up
    change_table :photos do |t|
      t.attachment :imagen
    end
  end

  def self.down
    remove_attachment :photos, :imagen
  end
end
