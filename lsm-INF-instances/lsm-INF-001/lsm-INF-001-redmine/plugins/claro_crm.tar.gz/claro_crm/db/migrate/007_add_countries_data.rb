# encoding: utf-8

class AddCountriesData < ActiveRecord::Migration
  def up
    Country.create! ({
      :name => "México",
      :currency => "Peso ($, MXN)",
      :population => 122300000,
      :active => true,
      :code => "mx",
      :timezone => "UTC/GMT -5",
      :zone => "norteamerica"})
    Country.create! ({
      name: "Costa Rica",
      currency: "Colón costarricense (₡, CRC)",
      population: 4872000,
      active: true,
      code: "cr",
      timezone: "UTC/GMT -6",
      zone: "centroamerica"})
    Country.create! ({
      name: "El Salvador",
      currency: "Dólar estadounidense ($, USD)",
      population: 6340000,
      active: true,
      code: "sv",
      timezone: "UTC/GMT -6",
      zone: "centroamerica"})
    Country.create! ({
      name: "Guatemala",
      currency: "Quetzal (Q, GTQ)",
      population: 15470000,
      active: true,
      code: "gt",
      timezone: "UTC/GMT -6",
      zone: "centroamerica"})
    Country.create! ({
      name: "Honduras",
      currency: "Lempira (HNL)",
      population: 8098000,
      active: true,
      code: "hn",
      timezone: "UTC/GMT -6",
      zone: "centroamerica"})
    Country.create! ({
      name: "Nicaragua",
      currency: "Córdoba (C$, NIO)",
      population: 6038652 ,
      active: true,
      code: "ni",
      timezone: "UTC/GMT -6",
      zone: "centroamerica"})
    Country.create! ({
      name: "Panamá",
      currency: "Balboa (oficial) (PAB) Dólar estadounidense (curso legal) ($, USD)",
      population: 3706596 ,
      active: true,
      code: "pa",
      timezone: "UTC/GMT -6",
      zone: "centroamerica"})
    Country.create! ({
      name: "Puerto Rico",
      currency: "Dólar estadounidense ($, USD)",
      population: 3548000 ,
      active: true,
      code: "pr",
      timezone: "UTC/GMT -4",
      zone: "caribe"})
    Country.create! ({
      name: "Rep. Dominicana",
      currency: "Peso (RD$,DOP)",
      population: 10400000 ,
      active: true,
      code: "do",
      timezone: "UTC/GMT -4",
      zone: "caribe"})
    Country.create! ({
      name: "Argentina",
      currency: "Peso ($, ARS)",
      population: 40117096 ,
      active: true,
      code: "ar",
      timezone: "UTC/GMT -3",
      zone: "sudamerica"})
    Country.create! ({
      name: "Brasil",
      currency: "Real (R$, BRL)",
      population: 202768562  ,
      active: true,
      code: "br",
      timezone: "UTC/GMT -3",
      zone: "sudamerica"})
    Country.create! ({
      name: "Chile",
      currency: "Peso ($, CLP)",
      population: 18006407 ,
      active: true,
      code: "cl",
      timezone: "UTC/GMT -3",
      zone: "sudamerica"})
    Country.create! ({
      name: "Colombia",
      currency: "Peso ($) (COP)",
      population: 47846160 ,
      active: true,
      code: "co",
      timezone: "UTC/GMT -5",
      zone: "sudamerica"})
    Country.create! ({
      name: "Ecuador",
      currency: "Dólar estadounidense ($, USD)",
      population: 16013143,
      active: true,
      code: "ec",
      timezone: "UTC/GMT -5",
      zone: "sudamerica"})
    Country.create! ({
      name: "Paraguay",
      currency: "Guaraní ( PYG )",
      population: 6783372,
      active: true,
      code: "py",
      timezone: "UTC/GMT -4",
      zone: "sudamerica"})
    Country.create! ({
      name: "Perú",
      currency: "Nuevo sol (S/, PEN)",
      population: 30814175,
      active: true,
      code: "pe",
      timezone: "UTC/GMT -5",
      zone: "sudamerica"})
    Country.create! ({
      name: "Uruguay",
      currency: "Peso ($, UYU)",
      population: 3286314,
      active: true,
      code: "uy",
      timezone: "UTC/GMT -3",
      zone: "sudamerica"})
  end

  def down
    Country.delete_all
  end
end
