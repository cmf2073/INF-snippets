class CreatePhoneNumbers < ActiveRecord::Migration
  def change
    create_table :phone_numbers do |t|
      t.string :number
      t.references :contact
    end
    add_index :phone_numbers, :contact_id
  end
end
