class CreateCountries < ActiveRecord::Migration
  def change
    create_table :countries do |t|
      t.string :name
      t.string :currency
      t.integer :population
      t.string :customer_service
      t.string :web
      t.string :facebook
      t.string :twitter
      t.boolean :active
      t.string :code
      t.string :timezone
    end
  end
end
