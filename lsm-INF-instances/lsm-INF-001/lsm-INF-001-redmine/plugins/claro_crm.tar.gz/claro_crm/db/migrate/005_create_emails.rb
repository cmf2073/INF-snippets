class CreateEmails < ActiveRecord::Migration
  def change
    create_table :emails do |t|
      t.string :email
      t.references :contact
    end
    add_index :emails, :contact_id
  end
end
