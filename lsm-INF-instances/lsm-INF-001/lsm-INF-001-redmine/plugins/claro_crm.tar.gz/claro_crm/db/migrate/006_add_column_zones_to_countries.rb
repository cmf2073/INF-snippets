class AddColumnZonesToCountries < ActiveRecord::Migration
  def change
    add_column :countries, :zone, :string
  end
end
