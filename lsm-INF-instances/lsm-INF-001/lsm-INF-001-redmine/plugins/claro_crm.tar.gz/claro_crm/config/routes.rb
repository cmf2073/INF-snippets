# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html
resources :contacts, only: [:index, :create,:add_photo, :destroy, :edit, :update]
resources :countries, only: [:index, :edit, :update]
resources :photos, only: [:index, :edit, :update, :destroy]

get 'contacts/country/:code' => 'contacts#country', :as => :country
get 'photos/add_photo/:id' => 'photos#add_photo' , :as => :add_photo
get 'photos/take_photo/:id' => 'photos#take_photo', :as => :take_photo
post 'contacts/new_contact/:code' => 'contacts#new_contact', :as => :new_contact
