# encoding: utf-8
Redmine::Plugin.register :claro_crm do
  name 'Claro CRM plugin'
  author 'Latino Americana de Servicios Moviles'
  description 'CRM plugin for Claro Viajes'
  version '1.0.1'

  menu :top_menu, :contacts, { :controller => 'contacts', :action => 'index' }, :caption => 'Contactos'

  project_module :Intranet do
    permission :visualizacion_de_contactos, {:contacts => [:index, :country ] } , :require => :member
    permission :edicion_de_contactos, {:contacts => [:new_contact, :edit,:destroy] } , :require => :member
    permission :edicion_de_paises, {:countries => [:edit] }, :require => :member
  end
end
